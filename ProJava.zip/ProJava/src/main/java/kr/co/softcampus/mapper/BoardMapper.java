package kr.co.softcampus.mapper;

public interface BoardMapper {

}
